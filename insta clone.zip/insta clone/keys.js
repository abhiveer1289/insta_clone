module.exports = {
    mongoUrl: "mongodb+srv://abhiveer:<password>@cluster0.wqnok7g.mongodb.net/?retryWrites=true&w=majority",
    Jwt_secret: "faslkfocvneofu"

};